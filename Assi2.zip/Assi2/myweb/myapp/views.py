from django.shortcuts import render
from django.http import HttpResponseRedirect
from .forms import UploadedPDFForm
from .utils import extract_text_from_pdf, preprocess_text, extract_keywords, generate_summary 

def upload_pdf(request):
    if request.method == 'POST':
        form = UploadedPDFForm(request.POST, request.FILES)
        if form.is_valid():
            pdf = form.save()
            text = extract_text_from_pdf(pdf.pdf.path)
            keywords = extract_keywords(text)
            summary = generate_summary(text)
            return render(request, 'result.html', {'keyword': keywords, 'summary':summary})
        return render(request, 'upload.html', {'form':form})

    form = UploadedPDFForm()
    return render(request, 'upload.html', {'form': form})