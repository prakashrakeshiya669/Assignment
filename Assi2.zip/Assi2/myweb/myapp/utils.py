import fitz #PyMuPDF
import nltk 
import nltk
nltk.download('popular')
print(nltk.data.path)
from nltk.tokenize import word_tokenize
from nltk.corpus import indian
from nltk.corpus import stopwords
from nltk.probability import FreqDist

def extract_text_from_pdf(pdf_file):
    text=""
    doc= fitz.open(pdf_file)
    for page_num in range(len(doc)):
        page = doc.load_page(page_num)
        text += page.get_text()
    return text

def preprocess_text(text):
    tokens = word_tokenize(text)
    stop_words = set(stopwords.words('marathi'))
    filtered_tokens = [word for word in tokens if word.lower() not in stop_words]
    return filtered_tokens

def extract_keywords(text, num_keywords=5):
    tokens = preprocess_text(text)
    freq_dist = FreqDist(tokens)
    return freq_dist.most_common(num_keywords)

def generate_summary(text, num_sentences=3):
    #implement your Summarization technique here
    # For demonstration purposes, let's just return the first few sentences 

    sentences = text.split('.')
    summary = '. '.join(sentences[:num_sentences])
    return summary

nltk.download('indian')